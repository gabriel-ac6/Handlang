import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'firebase_options.dart';

class UserData {
  final String firstName;
  final String lastName;

  UserData(this.firstName, this.lastName);
}

Future<void> main() async{
  WidgetsFlutterBinding.ensureInitialized();

  await Firebase.initializeApp(
    options: DefaultFirebaseOptions.currentPlatform,
  );
  runApp(MyHomePage());
}

class MyHomePage extends StatelessWidget {
  final FirebaseFirestore db = FirebaseFirestore.instance;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Firestore Example'),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            ElevatedButton(
              onPressed: () {
                // Add a document to Firestore
                db.collection('users').doc('user1').set({
                  'firstName': 'John',
                  'lastName': 'Doe',
                });
              },
              child: Text('Add User'),
            ),
            ElevatedButton(
              onPressed: () async {
                // Read data from Firestore
                DocumentSnapshot userSnapshot =
                await db.collection('users').doc('user1').get();
                if (userSnapshot.exists) {
                  var userData = UserData(
                    userSnapshot['firstName'],
                    userSnapshot['lastName'],
                  );
                  print("First Name: ${userData.firstName}, Last Name: ${userData.lastName}");
                } else {
                  print("Document not found");
                }
              },
              child: Text('Read User'),
            ),
          ],
        ),
      ),
    );
  }
}