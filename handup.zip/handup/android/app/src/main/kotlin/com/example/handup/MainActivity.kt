package com.example.handup

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
